# -*- coding: utf-8 -*-
"""
rss_sync app : create articles from rss feeds
"""

default_app_config = 'coop_cms.apps.rss_sync.apps.RssSyncAppConfig'