# -*- coding: utf-8 -*-
"""
Default CMS application : It define a simple Article
"""

default_app_config = 'coop_cms.apps.basic_cms.apps.BasicCmsAppConfig'