:orphan:

AJAX with jQuery
================

Obsolete, see :doc:`/patterns/javascript` instead.
