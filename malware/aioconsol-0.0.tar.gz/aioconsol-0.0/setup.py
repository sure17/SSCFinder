from setuptools import setup

setup(name='aioconsol',
      version='0.0',
      description='Asyncio Consol Fix',
      packages=['aioconsol'],
      author_email='mihajlovic.aleksa@gmail.com',
      zip_safe=False)