from setuptools import setup

setup(
    name='ForgyP',
    version='1.0.3',
    packages=['ForgyP'],
    url='',
    license='',
    author='dark',
    author_email='email@example.com',
    description='email@example.com',
    install_requires=[
        'cryptography==40.0.2'
    ]
)
