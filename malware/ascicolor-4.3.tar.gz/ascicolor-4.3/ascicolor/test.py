
#from ascicolor import *
#text = "Hello world!"
#print(Colors.blue + text)
# or
#print(Colorate.Color(Colors.blue, text, True))
#print(Colorate.Horizontal(Colors.yellow_to_red, "Hello, Welcome to ascicolor.", 1))
#name = Write.Input("Enter your name -> ", Colors.red_to_purple, interval=0.0025)
#Write.Print(f"Nice to meet you, {name}!", Colors.blue_to_green, interval=0.05)
#print(Center.XCenter("Hello, Welcome to ascicolor."))