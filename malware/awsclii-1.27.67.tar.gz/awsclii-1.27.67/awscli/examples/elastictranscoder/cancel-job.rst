**To cancel a job for ElasticTranscoder**

This cancels the specified job for ElasticTranscoder.

Command::

  aws elastictranscoder cancel-job --id 3333333333333-abcde3

