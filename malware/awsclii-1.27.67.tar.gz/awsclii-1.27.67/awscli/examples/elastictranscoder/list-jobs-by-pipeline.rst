**To retrieve a list of ElasticTranscoder jobs in the specified pipeline**

This example retrieves a list of ElasticTranscoder jobs in the specified pipeline.

Command::

  aws elastictranscoder list-jobs-by-pipeline --pipeline-id 1111111111111-abcde1

Output::

 {
    "Jobs": []
 }
