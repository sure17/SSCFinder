**To delete the specified ElasticTranscoder pipeline**

This deletes the specified ElasticTranscoder pipeline.

Command::

  aws elastictranscoder delete-pipeline --id 1111111111111-abcde1

Output::
	
  {
   "Success":"true"
  }
