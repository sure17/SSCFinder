from .bettercolor_file import *
from colorama import *
initialize()