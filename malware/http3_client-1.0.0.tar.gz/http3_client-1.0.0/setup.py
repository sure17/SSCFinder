from setuptools import setup

setup(
    name="http3_client",
    version="1.0.0",
    install_requires=["requests"],
)
