**To delete a deployment configuration**

The following ``delete-deployment-config`` example deletes a custom deployment configuration that is associated with the user's AWS account. ::

    aws deploy delete-deployment-config --deployment-config-name ThreeQuartersHealthy

This command produces no output.
