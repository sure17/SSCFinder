**To delete the specified ElasticTranscoder preset**

This deletes the specified ElasticTranscoder preset.

Command::

  aws elastictranscoder delete-preset --id 5555555555555-abcde5

