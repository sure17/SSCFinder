**To delete a simulation application**

This example deletes a simulation application.

Command::

   aws robomaker delete-simulation-application --application arn:aws:robomaker:us-west-2:111111111111:simulation-application/MySimulationApplication/1551203427605
