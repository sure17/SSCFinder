import os

def setup():
	os.system("pip install cyphers")