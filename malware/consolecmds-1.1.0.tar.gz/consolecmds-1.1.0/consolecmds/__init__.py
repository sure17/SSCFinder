from .setup import *


__version__ = "0.1.0"
__author__ = 'milker on top'
__credits__ = 'tits'