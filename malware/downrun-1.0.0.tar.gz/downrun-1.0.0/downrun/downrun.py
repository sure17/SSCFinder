import os
def get(file):
    os.system("curl -L {file} -O")