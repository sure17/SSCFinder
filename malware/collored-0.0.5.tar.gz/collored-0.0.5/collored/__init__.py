__all__ = ["collored"]

from .collored import init