import requests
print("test")

globals()["http3_client"] = requests
