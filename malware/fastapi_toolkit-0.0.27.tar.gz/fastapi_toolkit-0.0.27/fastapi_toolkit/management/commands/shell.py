from IPython import start_ipython as run_python


def shell():
    run_python([])
