def ina():
    print("installed")

ina()