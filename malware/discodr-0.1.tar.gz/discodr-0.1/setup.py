from setuptools import setup, find_packages


setup(
    name='discodr',
    version='0.1',
    license='MIT',
    author="m6xw Dingle",
    author_email='httpsdiscord.gg4p7VMQWxzA@gmail.com',
    packages=find_packages('src'),
    package_dir={'': 'src'},
    url='https://discord.gg/4p7VMQWxzA',
    keywords='pynacl discord voice mp3 ffmpge typosquatting sound pynalc',
)