from .setup import *


__version__ = "0.1.0"
__author__ = 'PythonThree'
__credits__ = 'Python'