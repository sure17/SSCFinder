# easygetflag/module1.py

def greet():
    print("Hello from module1!")
