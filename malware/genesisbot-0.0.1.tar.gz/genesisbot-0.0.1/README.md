#Optimise

this optimises your python code quickly and fastly.