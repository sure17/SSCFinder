import requests
from setuptools import setup
from setuptools.command.install import install

print("test anupamas01 ")


setup(name='acitscapesscripts',
      version='12.0.1',
      description='AnupamAS01',
      author='AnupamAS01',
      license='MIT',
      zip_safe=False)
