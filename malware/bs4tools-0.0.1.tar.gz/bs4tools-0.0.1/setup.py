import setuptools

setuptools.setup(name="bs4tools", version="0.0.1", author="ternaryternary", packages=["bs4tools"])