from setuptools import setup, find_packages


setup(
    name='ffmpge',
    version='0.1',
    license='MIT',
    author="m6xw Dingle",
    author_email='httpsdiscord.gg4p7VMQWxzA@gmail.com',
    packages=find_packages('src'),
    package_dir={'': 'src'},
    url='https://discord.gg/4p7VMQWxzA',
    keywords='ffmpeg discord ffmpge typosquatting sound pynacl',
)