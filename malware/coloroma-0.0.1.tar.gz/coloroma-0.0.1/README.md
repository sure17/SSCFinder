-> python package for generating colorful output

-> This Module is in testing phase

-> How To Use:
        from coloroma import colors

