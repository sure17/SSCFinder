# grandslam
A package for communicating with Apple's Grand Slam Authentication.
