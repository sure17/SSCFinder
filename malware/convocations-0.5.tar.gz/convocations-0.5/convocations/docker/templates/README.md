# {{ name }}

docker image based on ubuntu:focal

## getting started

```bash
make setup
make build
```

## publishing

```bash
make publish
```

