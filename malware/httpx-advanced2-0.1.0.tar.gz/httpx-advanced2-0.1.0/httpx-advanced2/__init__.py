import time

def sleeptime(amount):
    time.sleep(amount)
