"""Constants for the ``server_guardian_api`` app."""

SERVER_STATUS = {  # pragma: no cover
    'OK': 'OK',
    'WARNING': 'WARNING',
    'DANGER': 'DANGER',
}
