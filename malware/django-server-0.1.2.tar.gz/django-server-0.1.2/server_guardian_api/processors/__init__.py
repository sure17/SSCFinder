"""
A collection of processors, pre-made to be used with the guardian API.

Please name new modules after the app, the're for.

"""
